/*
 * cromemco-d+7a.c
 * 
 * Emulation of the Cromemco D+7A I/O 
 *
 * Copyright (C) 2020 by David McNaughton
 * D+7A audio part copyright (C) 2024 by Ansgar Kueckes
 * 
 * History:
 * 14-JAN-20    1.0     Initial Release
 */
#include <stdlib.h>
#include <stdio.h>
#include "sim.h"
#include "simglb.h"
#include "sys/time.h"
#include "string.h"

#ifdef HAS_NETSERVER
#include "netsrv.h"
#endif
//#define LOG_LOCAL_LEVEL LOG_DEBUG
#include "log.h"

static const char *TAG = "D+7AIO";

#define PORT_COUNT  8

BYTE inPort[PORT_COUNT];
BYTE outPort[PORT_COUNT];

/* -------------- PortAudio ---------------- */

/*
    Two buffers are serviced by writing with a 16 kHz rate to port 0x19
    (channel 1) and port 0x1b (channel 2). The ring buffer works as source
    for the PortAudio stream, which is fed by a callback function that
    is called everytime the stream buffer needs a refresh.
    
    D+7A application:
    
    Use the 62 Hz vertical blank signal to sync the playback of tunes or
    sounds from a score, and write to the D+7A ports in a 16 kHz play loop.
    
    Due to the lack of real time capabilities of most operating systems,
    it is not possible to execute the play loop exactly with 16 kHz. As
    a consequence, there will always be noise artifacts in the stream,
    which cannot be fully compensated.
*/

#include <math.h>
#include "portaudio.h"
#define SAMPLE_RATE   (16000)           /* sample rate in Hz */
#define BUFFER_SIZE   (2048)	        /* buffer size, defines audio delay */

typedef struct
{
    char channel_1;
    char channel_2;
} paSampleData;

typedef struct {
        paSampleData *buffer;           /* actual ring buffer for samples */
        int start;                 	/* index to first entry in ring buffer */
        int end;                        /* index to next free buffer entry */
        int lock;			/* locks buffer changes during callback */
        int count;			/* number of samples in buffer */
} paRingBuffer;

typedef struct {
	paSampleData sample;		/* actual sample */
	uint8_t status;			/* 0=OK, 1=buffer overflow, 2=dropout */
} debugData;

debugData waveBuffer[1000000];
int waveIndex;

/* This routine will be called by the PortAudio engine when audio is needed.
** It may called at interrupt level on some machines so don't do anything
** that could mess up the system like calling malloc() or free().
*/
static int paCallback( const void *inputBuffer, void *outputBuffer,
                           unsigned long framesPerBuffer,
                           const PaStreamCallbackTimeInfo* timeInfo,
                           PaStreamCallbackFlags statusFlags,
                           void *userData )
{
    /* cast data passed through stream to our structure. */
    paRingBuffer *ring_buffer = (paRingBuffer*)userData;
    char *out = (char*)outputBuffer;
    unsigned int i, index;

    /* prevent unused variable warning. */
    (void) inputBuffer;
    (void) timeInfo;
    (void) statusFlags;
    
    if (ring_buffer->lock) return 0;

    /* lock ring buffer */
    ring_buffer->lock = 1;
    
    index = ring_buffer->start;

    /* copy ring buffer to wave buffer */
    for( i=0; i<framesPerBuffer; i++ )
    {
        /* kill sound if out of data */
        if (ring_buffer->count == 0) {
            /* silence */
            *out++ = 0;		/* channel 1 */
            *out++ = 0;		/* channel 2 */
        }
        else {
//            if (ring_buffer->buffer[index].channel_1 != 0)
//                printf("%d %d %d %d\n\r", i, ring_buffer->count, ring_buffer->buffer[index].channel_1, ring_buffer->buffer[index].channel_2);
            /* copy ring buffer */
            *out++ = ring_buffer->buffer[index].channel_1;
            *out++ = ring_buffer->buffer[index].channel_2;
            ring_buffer->count--;
            index++;
            if (index >= BUFFER_SIZE) index = 0;
	}
    }

    /* update start pointer */
    ring_buffer->start = index;

    /* unlock ring buffer */
    ring_buffer->lock = 0;

    return 0;
}

static paRingBuffer ring_buffer;                   /* intermediate buffer for port data */
static paSampleData sample_buffer[BUFFER_SIZE];    /* actual sample buffer */

PaStream *stream;

void portaudio_init(void) {
    PaError err;

    /* Initialize library before making any other calls. */
    err = Pa_Initialize();
    if( err != paNoError ) goto error;

    /* Open an audio I/O stream. */
    err = Pa_OpenDefaultStream( &stream,
                                0,            /* no input channels */
                                2,            /* stereo output */
                                paInt8,       /* signed char output */
                                SAMPLE_RATE,
                                256,          /* frames per buffer */
                                paCallback,
                                &ring_buffer );
    if( err != paNoError ) goto error;

    err = Pa_StartStream( stream );
    if( err != paNoError ) goto error;
    	
    waveIndex = 0;
        
    return;

error:
    Pa_Terminate();
    return;
}

void portaudio_stop(void) {
    PaError err;

    err = Pa_StopStream( stream );
    if( err != paNoError ) goto error;
    err = Pa_CloseStream( stream );
    if( err != paNoError ) goto error;

    return;

error:
    Pa_Terminate();
    return;
}

/* -------------- End PortAudio ---------------- */

static char channel_1;          /* current channel 1 sample */
static char channel_2;          /* current channel 2 sample */
static unsigned long last_usec; /* time stamp of last port command in microseconds */

void cromemco_d7a_callback(BYTE *data) {
    
    int i;
    inPort[0] = *data++;
    for (i=1; i < PORT_COUNT; i++) {
        inPort[i] = (*data++) - 128;
    }
}

void cromemco_d7a_init(void) {

    inPort[0] = 0xFF;
    
#ifdef HAS_NETSERVER
    net_device_service(DEV_D7AIO, cromemco_d7a_callback);
#endif

    /* Initialize our data for use by callback. */
    ring_buffer.start = ring_buffer.end = 0;
    ring_buffer.buffer = sample_buffer;
    ring_buffer.lock = 0;
    ring_buffer.count = 0;
    channel_1 = 0;
    channel_2 = 0;
    memset(ring_buffer.buffer, 0, sizeof(sample_buffer));

    /* initialize PortAudio */
    portaudio_init();

    /* initialize time stamp (0=undefined) */
    last_usec = 0;
}

void cromemco_d7a_off(void) {

    int i;
    int16_t buf[1024];
    int buf_index = 0;
    
    struct {
    	char chunk_id[4];
    	uint32_t cunk_size;
    	char format[4];
    	char subchunk1_id[4];
    	uint32_t subchunk1_size;
    	uint16_t audio_format;
    	uint16_t num_channels;
    	uint32_t sample_rate;
    	uint32_t byte_rate;
    	uint16_t block_align;
    	uint16_t bits_per_sample;
    	char subchunk2_id[4];
    	uint32_t subchunk2_size;
    } header;

    /* shutdown PortAudio */
    portaudio_stop();
    
    /* ---------- export as wave file ---------- */
    
    /* open wave file */
    FILE *fp = fopen("out.wav", "wb");
    if (!fp) {
    	printf("Couldn't open file out.wav\n");
    	return;
    }

    /* setup wave header */
    memcpy(header.chunk_id, "RIFF", 4);
    header.cunk_size = waveIndex * 4 + 40;
    memcpy(header.format, "WAVE", 4);
    memcpy(header.subchunk1_id, "fmt ", 4);
    header.subchunk1_size = 16;
    header.audio_format = 1;
    header.num_channels = 2;
    header.sample_rate = SAMPLE_RATE;
    header.byte_rate = SAMPLE_RATE * 4;
    header.block_align = 4;
    header.bits_per_sample = 16;
    memcpy(header.subchunk2_id, "data", 4);
    header.subchunk2_size = waveIndex * 4;
    
    /* write wave header */
    fwrite(&header, sizeof(header), 1, fp);

    /* write sample data */
    for (i=0; i<waveIndex; i++) {
    	buf[buf_index++] = waveBuffer[i].sample.channel_1 * 256;
    	buf[buf_index++] = waveBuffer[i].sample.channel_2 * 256;
    	if (buf_index == 1024) {
            buf_index = 0;
            fwrite(buf, 1024, 2, fp);
    	}
    	
    	/* debug output */
    	if (waveBuffer[i].status > 0) {
    	    printf("index=%d %s\n\r", i, (waveBuffer[i].status == 1) ? "overflow" : "dropout");
    	}
    }
    
    fclose(fp);
}

void cromemco_d7a_out(BYTE port, BYTE data)
{
    outPort[port] = data;
    int i, count;
    struct timeval tv;
    unsigned long current_usec, timeout;
    
    LOGD(TAG, "Output %d on port %d", data, port);
    
    /* JS-1 audio */
    if ((port == 1) || (port == 3)) {

	/* get delta of samples since last write to port */
        gettimeofday(&tv, NULL);
        current_usec = tv.tv_usec;
        if (last_usec == 0) last_usec = current_usec;
        if (current_usec >= last_usec)
            count = ((current_usec - last_usec) * SAMPLE_RATE / 1000000) + 1;
        else 
            count = ((current_usec + 1000000 - last_usec) * SAMPLE_RATE / 1000000) + 1;
	last_usec = current_usec;
        
    	/* wait for being unlocked */
    	timeout = 1000000;
    	while(ring_buffer.lock && !timeout) timeout--;
    	if (!timeout) return;
    		
        waveBuffer[waveIndex].status = 0;	/* OK */

	/* ignore dropouts caused by loss of CPU */
    	if (count > 8) {
    		count = 0;
                waveBuffer[waveIndex-1].status = 2; /* dropout */
    	}

        /* buffer overflow */
        if (count > (BUFFER_SIZE - ring_buffer.count)) {
      	    /* drop new data */
      	    count = BUFFER_SIZE - ring_buffer.count;
            waveBuffer[waveIndex-1].status = 1;	/* overflow */
        }

        /* append to ring buffer */
        for (i=0; i<count; i++) {
            ring_buffer.buffer[ring_buffer.end].channel_1 = channel_1;
            ring_buffer.buffer[ring_buffer.end].channel_2 = channel_2;
            ring_buffer.end++;
            if (ring_buffer.end >= BUFFER_SIZE) ring_buffer.end = 0;

            /* debug log */
            waveBuffer[waveIndex].sample.channel_1 = channel_1;
            waveBuffer[waveIndex].sample.channel_2 = channel_2;
            waveIndex++;
        }
        ring_buffer.count += count;

        /* update current sample */
        if (port == 1)
              channel_1 = data;
        else
              channel_2 = data;
    }

#ifdef HAS_NETSERVER
    // if (net_device_alive(DEV_D7AIO)) {
        net_device_send(DEV_D7AIO, (char *)&data, 1);
    // }
#endif
}

void cromemco_d7a_D_out(BYTE data) { cromemco_d7a_out(0, data); }
void cromemco_d7a_A1_out(BYTE data) { cromemco_d7a_out(1, data); }
void cromemco_d7a_A2_out(BYTE data) { cromemco_d7a_out(2, data); }
void cromemco_d7a_A3_out(BYTE data) { cromemco_d7a_out(3, data); }
void cromemco_d7a_A4_out(BYTE data) { cromemco_d7a_out(4, data); }
void cromemco_d7a_A5_out(BYTE data) { cromemco_d7a_out(5, data); }
void cromemco_d7a_A6_out(BYTE data) { cromemco_d7a_out(6, data); }
void cromemco_d7a_A7_out(BYTE data) { cromemco_d7a_out(7, data); }

BYTE cromemco_d7a_in(BYTE port)
{
        return inPort[port];
}

BYTE cromemco_d7a_D_in(void) { return cromemco_d7a_in(0); };
BYTE cromemco_d7a_A1_in(void) { return cromemco_d7a_in(1); };
BYTE cromemco_d7a_A2_in(void) { return cromemco_d7a_in(2); };
BYTE cromemco_d7a_A3_in(void) { return cromemco_d7a_in(3); };
BYTE cromemco_d7a_A4_in(void) { return cromemco_d7a_in(4); };
BYTE cromemco_d7a_A5_in(void) { return cromemco_d7a_in(5); };
BYTE cromemco_d7a_A6_in(void) { return cromemco_d7a_in(6); };
BYTE cromemco_d7a_A7_in(void) { return cromemco_d7a_in(7); };
