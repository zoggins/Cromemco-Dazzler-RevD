/******************************************************************************

	bmpconvert.c

	Converts the Windows BMP format into the Cromemco Dazzler memory formats for
	loading images into Dazzler video memory.
	
	BMP formats are supported with 1, 4, 8 and 24 bits per pixel, however
	it is recommended to use 1 bit per pixel for bilevel and 4 bits per
	pixel for color images. BMP files must have a resolution of either 128x128,
	64x64 or 32x32 pixels.
	
	Assumed color map for indexed files is BLK, RED, GRN, YEL, BLU, MAG, CYA,
	WHT (in that order). All other color maps will produce false colors.
	Due to the limited color space of the Dazzler, it is recommended to apply an
	adaquate dithering scheme before transferring photographs into a Dazzler
	format. Again note that you *must* use the above color palette in order
	to produce images with correctly indexed colors.
	
	bmpconvert just does the necessary conversions, it does not adjust
	the size of the image nor does it check for file format integrity. Use your
	favourite image editing software to resize and/or dither the source image
	bitmap.
	
	Supported are standard (nibble) format with 16 colors and grayscale, as well
	as 4x4 bilevel format.
	
	24-bit bitmap color information will be mapped as good as possible to the
	16 colors provided by the Dazzler. Indexed bitmaps (=bitmaps working with
	palettes) require a palette which is ordered according to the Dazzler color
	codes:
	
		 0: BLACK (000000)
		 1: DARK RED (7F0000)
		 2: DARK GREEN (007F00)
		 3: DARK YELLOW (7F7F00)
		 4: DARK BLUE (00007F)
		 5: DARK PURPLE (7F007F)
		 6: DARK CYAN (007F7F)
		 7: GRAY (7F7F7F)
		 8: BLACK (000000)
		 9: LIGHT RED (FF0000)
		10: LIGHT GREEN (00FF00)
		11: YELLOW (FFFF00)
		12: LIGHT BLUE (0000FF)
		13: MAGENTA (FF00FF)
		14: CYAN (00FFFF)
		15: WHITE (FFFFFF)
	
	The proper foreground color for bilevel images has to be selected on the
	Dazzler.
	
	(c) 2024 by Ansgar Kueckes (www.hp9845.net)

******************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#ifdef __WIN32__
#include <windows.h>
#endif

#pragma pack(1)

typedef struct {
	WORD id;
	WORD data;
} HPINT;

typedef struct {
	BYTE peBlue;
	BYTE peGreen;
	BYTE peRed;
	BYTE peFlags;	
} Palette_Entry;

#pragma pack()

typedef enum { COLOR, GRAYSCALE, BILEVEL } DazzlerFormat;

void print_usage(char *command)
{
	printf("\nUsage: %s [<options>] <infile> <outfile>\n", command);
	printf("       <infile>    input image file\n");
	printf("       <outfile>   output image file\n");
	printf("\nwith <options>:\n");
	printf("       -color      produce standard color format (default)\n");
	printf("       -grayscale  produce standard grayscale format\n");
	printf("       -bilevel    produce bilevel (4x4) format\n");
	printf("       -info       output file info only\n");
	return;
}

/*
	convert Windows BMP image file to Dazzler graphics format
*/
int bmp2dazzler(DazzlerFormat dazzler_format, FILE *ifp, FILE *ofp, DWORD offset)
{
  BITMAPINFOHEADER infoheader;
  BITMAPCOREHEADER coreheader;
  DWORD header_size;
  BYTE buffer[256];
  BYTE video_buffer[2048];
  BYTE color_mask, pixel_mask, foreground;
  BYTE palette[9];

  int numrows,rowsize,width,height,depth,row,pos,target,luminance,i,j;
  
  fseek(ifp, 14, SEEK_SET);
  fread(&header_size, sizeof(header_size), 1, ifp);
  fseek(ifp, 14, SEEK_SET);

  foreground = 0xf;	/* default foreground color white */

  /* perform the necessary checks */

  switch(header_size) {
  case 40:
  		fread(&infoheader, sizeof(infoheader), 1, ifp);
  		fread(&palette, 9, 1, ifp);
			depth = infoheader.biBitCount;
			width = infoheader.biWidth;
			height = infoheader.biHeight;
			if (infoheader.biClrUsed > 0) {
				/* get foreground color from palette */
				foreground = 0;
				for (j=0; j<3; j++) {
					if (palette[6+2-j] > 0x40) foreground |= 0x1 << j;	// base colors
					if (palette[6+2-j] > 0x80) foreground |= 0x8;				// highlight
				}
			}
			if (infoheader.biCompression!= BI_RGB) {
				fprintf(stderr, "Error: input image uses compression (must be uncompressed)\n");
				return -1;
			}
			break;

  case 12:	fread(&coreheader, sizeof(coreheader), 1, ifp);
			depth = coreheader.bcBitCount;
			width =coreheader.bcWidth;
			height = coreheader.bcHeight;
 			break;

  default:	fprintf(stderr, "Warning: unsupported BMP version\n");
  }

	if (((width != 128) || (abs(height) != 128)) &&
		  ((width != 64) || (abs(height) != 64)) &&
		  ((width != 32) || (abs(height) != 32))) {
		fprintf(stderr, "Error: input image dimensions do not match (must be 128x128, 64x64 or 32x32)\n");
		return -1;
	}

  if ((depth != 1) && (depth != 4) && (depth != 8) && (depth != 24)) {
		fprintf(stderr, "Error: unsupported color depth in BMP file (must be 1, 4, 8 or 24 bit/pixel)\n");
		return -1;
  }
  
  if (((dazzler_format == COLOR) || (dazzler_format == GRAYSCALE)) && (width > 64)) {
		fprintf(stderr, "Error: color and grayscale must have dimensions 64x64 or 32x32\n");
		return -1;
  }
  
  if ((dazzler_format == BILEVEL) && (width < 64)) {
		fprintf(stderr, "Error: bilevel must have dimensions 64x64 or 128x128\n");
		return -1;
  }

	if ((dazzler_format == BILEVEL) && (depth > 1)) {
		fprintf(stderr, "Error: not a bilevel input image\n");
		return -1;
	}

  rowsize = width * depth / 8;
  numrows = abs(height);
  
//  printf("width = %d, height = %d, rowsize = %d, numrows = %d offset = %X\n", width, height, rowsize, numrows, (unsigned int)offset);
  
	/* clear video buffer */
	memset(video_buffer, 0, 2048);

  /* now start the conversion process, line by line */
  for (row=0; row<numrows; row++) {
  	
		/* get row from input file */
		if (height < 0) fseek(ifp, offset+(row*rowsize), SEEK_SET);
		else fseek(ifp, offset+((numrows-1-row)*rowsize), SEEK_SET);
  	fread(buffer, rowsize, 1, ifp);

		for (i=0; i<width; i++) {

			/* determine target address in video buffer */
			if (dazzler_format == BILEVEL) {
				target = (row / 2) * 16 + (i / 4);
				if ((row < 64) && (i >= 64)) target += 496;
				else if ((row >= 64) && (i < 64)) target += 512;
				else if ((row >= 64) && (i >= 64)) target += 1008;
			}
			else {
				target = row * 16 + (i / 2);
				if ((row < 32) && (i >= 32)) target += 496;
				else if ((row >= 32) && (i < 32)) target += 512;
				else if ((row >= 32) && (i >= 32)) target += 1008;
			}
				
		  switch(dazzler_format) {
		  case COLOR:
		  case GRAYSCALE:
				switch (depth) {
				case 1: /* bilevel: pixel maps to white */
						pixel_mask = foreground;
						color_mask = 0x80 >> (i % 8);
						if (i % 2) pixel_mask <<= 4;
						if (buffer[i / 8] & color_mask) {
							video_buffer[target] |= pixel_mask;
						}
					break;

				case 4: /* indexed, palette must match Dazzler colors/shades */
					if (i%2 == 0) {
						video_buffer[target] |= (buffer[i/2] & 0x0f) << 4;
						video_buffer[target] |= (buffer[i/2] & 0xf0) >> 4;
					}
					break;

				case 8: /* indexed, palette must match Dazzler colors/shades */
					switch (dazzler_format) {
					case GRAYSCALE:
						pixel_mask = buffer[i] >> 4;
						if (i % 2) pixel_mask <<= 4;
						video_buffer[target] |= pixel_mask;
						break;
					case COLOR:
						pixel_mask = (buffer[i] & 0xf);
						if (i%2) pixel_mask <<= 4;
						video_buffer[target] |= pixel_mask;
						break;
					default:;
					}
					break;

				case 24: /* true color, approximated to Dazzler colors */
					switch (dazzler_format) {
					case GRAYSCALE:
						/* average over all colors */
						luminance = 0;
						for (j=0; j<3; j++) luminance += buffer[(i*3) + j];
						pixel_mask = (luminance / 3)  >> 4;
						if (i%2) pixel_mask <<= 4;
						video_buffer[target] |= pixel_mask;
						break;
					case COLOR:
						/* find closest match */
						pixel_mask = 0;
						for (j=0; j<3; j++) {
							pos = (i*3)+(2-j);
							if (buffer[pos] >= 0x40) pixel_mask |= 0x1 << j;	// base colors
							if (buffer[pos] >= 0x80) pixel_mask |= 0x8;				// highlight
						}
						if (i%2) pixel_mask <<= 4;
						video_buffer[target] |= pixel_mask;
						break;
					default:;
					}
				}
				break;

		  case BILEVEL:
		  	/* process only full bytes */
		  	if (i%8 == 0) {
		  		pixel_mask = buffer[i/8];
					if (row % 2) {
						/* first nibble */
						video_buffer[target] |= (pixel_mask & 0x80) >> 5;	// D7 -> D2
						video_buffer[target] |= (pixel_mask & 0x40) >> 3;	// D6 -> D3
						video_buffer[target] |= (pixel_mask & 0x20) << 1;	// D5 -> D6
						video_buffer[target] |= (pixel_mask & 0x10) << 3;	// D4 -> D7
						/* second nibble */
						video_buffer[target+1] |= (pixel_mask & 0x08) >> 1;	// D3 -> D2
						video_buffer[target+1] |= (pixel_mask & 0x04) << 1;	// D2 -> D3
						video_buffer[target+1] |= (pixel_mask & 0x02) << 5;	// D1 -> D6
						video_buffer[target+1] |= (pixel_mask & 0x01) << 7;	// D0 -> D7
					}
					else {
						/* first nibble */
						video_buffer[target] |= (pixel_mask & 0x80) >> 7;	// D7 -> D0
						video_buffer[target] |= (pixel_mask & 0x40) >> 5;	// D6 -> D1
						video_buffer[target] |= (pixel_mask & 0x20) >> 1;	// D5 -> D4
						video_buffer[target] |= (pixel_mask & 0x10) << 1;	// D4 -> D5
						/* second nibble */
						video_buffer[target+1] |= (pixel_mask & 0x08) >> 3;	// D3 -> D0
						video_buffer[target+1] |= (pixel_mask & 0x04) >> 1;	// D2 -> D1
						video_buffer[target+1] |= (pixel_mask & 0x02) << 3;	// D1 -> D4
						video_buffer[target+1] |= (pixel_mask & 0x01) << 5;	// D0 -> D5
					}
				}
		  }
	  }
	}
  
	if (((dazzler_format == BILEVEL) && (width > 64))
		|| ((dazzler_format != BILEVEL) && (width > 32)))
		fwrite(video_buffer, 2048, 1, ofp);
	else
		fwrite(video_buffer, 512, 1, ofp);

  return 0;
}

int main(int argc, char *argv[])
{
  int i,count;
  int result = -1;
  BOOL info = FALSE;
  FILE *ifp;
  FILE *ofp;
  char *infile = 0;
  char *outfile = 0;
  char tmp[MAX_PATH];
  DazzlerFormat dazzler_format = COLOR;
  BYTE buffer[256];
  DWORD offset;
  WORD id;
  
  if (argc < 2) { print_usage(argv[0]); exit(0); }

  /* command line processing */
  for ( count = 1; count < argc ; count++)
  {
	if (!strcmp(argv[count], "-color"))
		 { dazzler_format = COLOR; continue; }

	if (!strcmp(argv[count], "-grayscale"))
		 { dazzler_format = GRAYSCALE; continue; }

	if (!strcmp(argv[count], "-bilevel"))
		 { dazzler_format = BILEVEL; continue; }

	if (!strcmp(argv[count], "-info"))
		 { info = TRUE; continue; }

	if (!strncmp(argv[count], "-", 1) && (count < argc))
		 { print_usage(argv[0]); exit(0); }

	if (!infile) { infile = argv[count]; continue; }
	if (!outfile) { outfile = argv[count]; continue; }
  }
  
  if ((info && !infile) || (!info && !outfile)) { print_usage(argv[0]); exit(0); }
  	
  for (i=0; i<3; i++) {
  	ifp = NULL;
  	ofp = NULL;
  }
  
  /* open input file */
  if (!(ifp = fopen(infile, "rb"))) {
	  	if (!(ifp = fopen(tmp, "rb"))) {
			fprintf(stderr, "Could not open file \"%s\" or file \"%s\"\n", infile, tmp);
			exit(-1);
		}
  }

  fseek(ifp, 0, SEEK_SET);
  fread(buffer, 256, 1, ifp);
  id = buffer[0]*256 + buffer[1];

  /* get system infos */
  switch (id) {
  case 0x424d:  	
		offset = *((DWORD *)(buffer + 10));
		break;
  default:
  	fprintf(stderr, "Unknown input file format\n");
  	exit(-1);
  }

  if (info) printf("\nInfo on file %s:\n\n", infile);

  switch (id) {
  case 0x424d:	/* BMP input */
  				if (info) {
  					printf(" File type: Windows BMP\n");
  					printf(" Reported file size: %lu bytes\n", *((DWORD *)(buffer + 2)));
  					printf(" Dimensions: %ld by %ld pixel\n", *((LONG *)(buffer + 18)), *((LONG *)(buffer + 22)));
  					printf(" Color depth: %u bit(s) per pixel\n", *((WORD *)(buffer + 28)));
  					printf(" Compression: ");
  					switch (*((DWORD *)(buffer + 30))) {
  					case 0: printf("no compression\n"); break;
  					case 1: printf("run length encoded (4 bpp, unsupported)\n"); break;
  					case 2: printf("run length encoded (8 bpp, unsupported)\n"); break;
  					case 3: printf("bitfield (unsupported)\n"); break;
  					}
  				}
  				else {  		
	  				/* open output file */
						if (!(ofp = fopen(outfile, "wb"))) {
							fprintf(stderr, "Could not open file \"%s\"\n", outfile);
							exit(-1);
						}
	
						/* start file conversion */
		  			result = bmp2dazzler(dazzler_format, ifp, ofp, offset);
		  		}
	  			break;
	
  default:		fprintf(stderr, "Unknown input file format\n");
  }

  /* cleanup */
	if (ifp) fclose(ifp);
	if (ofp) fclose(ofp);

  exit(result);
}
